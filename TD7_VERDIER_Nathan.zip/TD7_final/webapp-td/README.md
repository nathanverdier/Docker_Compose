# Webapp TD

Application web pour le TD de CI/CD avec Gitea Actions.

## Tests

```bash
cargo test
```
